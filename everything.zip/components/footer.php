<footer class="height-1">
    <p>
        footer: <a href="https://www.w3schools.com/css/css3_transitions.asp" target="_blank">from w3schools</a>
    </p>
    <script src="../scripts/function.js"></script>
    
</footer>